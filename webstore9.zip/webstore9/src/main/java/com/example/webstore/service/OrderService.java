package com.example.webstore.service;

import com.example.webstore.domain.Order;

public interface OrderService {
	
	void processOrder(String  productId, long quantity);
	
	Long saveOrder(Order order);
}
