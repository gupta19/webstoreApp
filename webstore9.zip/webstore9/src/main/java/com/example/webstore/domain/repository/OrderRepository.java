package com.example.webstore.domain.repository;

import com.example.webstore.domain.Order;

public interface OrderRepository {
	Long saveOrder(Order order);
}
